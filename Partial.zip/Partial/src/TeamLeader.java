
public class TeamLeader extends Angajat{
	
	public TeamLeader(String nume, int varsta, int aniExperienta, int tarifPerOra) {
		super(nume, varsta, aniExperienta, tarifPerOra);
		
	}

}
