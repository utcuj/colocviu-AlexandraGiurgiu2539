import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		System.out.println("Introduceti numarul de angajati:");
		Scanner nrAngajati = new Scanner(System.in);
		String nr = nrAngajati.nextLine();
		System.out.println("In companie sunt " + nr + " angajati");
	
	Manager mng=new Manager("Teodora", 25, 5, 20);
	System.out.println("Manager: " + mng.toString());
	System.out.println("Salariu: " + mng.salariu(mng.tarifPerOra, 350, 400));
	
	TeamLeader team1=new TeamLeader("Paul", 28, 7, 15);
	System.out.println("Team Leader: " + team1.toString());
	System.out.println("Salariu: " + team1.salariu(team1.tarifPerOra, 280, 300));
	
	TeamLeader team2=new TeamLeader("George", 27, 5, 15);
	System.out.println("Team Leader: " + team2.toString());
	System.out.println("Salariu: " + team1.salariu(team1.tarifPerOra, 300, 200));
	
	Developer dev1=new Developer("Cristi", 23, 3, 10);
	System.out.println("Developer: " + dev1.toString());
	System.out.println("Salariu: " + dev1.salariu(dev1.tarifPerOra, 320, 200));
	
	Developer dev2=new Developer("Maria", 24, 2, 10);
	System.out.println("Developer: " + dev2.toString());
	System.out.println("Salariu: " + dev2.salariu(dev2.tarifPerOra, 320, 100));
	
	Developer dev3=new Developer("Ionut", 32, 8, 10);
	System.out.println("Developer: " + dev3.toString());
	System.out.println("Salariu: " + dev3.salariu(dev3.tarifPerOra, 320, 100));
	
	Developer dev4=new Developer("Simona", 27, 6, 10);
	System.out.println("Developer: " + dev4.toString());
	System.out.println("Salariu: " + dev4.salariu(dev4.tarifPerOra, 320, 200));
	
	dev1.rezolvaTask("rezolva problema 5");
	dev2.rezolvaTask("rezolva problema 13");
	
	Companie cmp=new Companie();
	
	cmp.adaugaAngajat(mng);
	cmp.adaugaAngajat(team1);
	cmp.adaugaAngajat(team2);
	cmp.adaugaAngajat(dev1);
	cmp.adaugaAngajat(dev2);
	cmp.adaugaAngajat(dev3);
	cmp.adaugaAngajat(dev4);
	
	cmp.afisare();
	
	cmp.stergeAngajat(dev3);
	
	cmp.afisare();
	
	
	}
}
