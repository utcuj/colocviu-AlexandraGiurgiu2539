
public class Manager extends Angajat {
	
	public Manager (String nume, int varsta, int aniExperienta, int tarifPerOra) {
		super(nume, varsta, aniExperienta, tarifPerOra);
	}
	
	public String toString() {
		return nume + ", " + varsta + " de ani, " + aniExperienta + " ani experienta, " + tarifPerOra + " pe ora";
	}
	
	
}