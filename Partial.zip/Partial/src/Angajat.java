
public abstract class Angajat {
	String nume;
	int varsta;
	int aniExperienta;
	int tarifPerOra;
	
	public int salariu (int tarifPerOra, int nrOreLucrate, int bonusNivel) {
		int salariu=tarifPerOra*nrOreLucrate+bonusNivel;
		return salariu;
	}
	
	public Angajat(String nume, int varsta, int aniExperienta, int tarifPerOra) {
		this.nume=nume;
		this.varsta=varsta;
		this.aniExperienta=aniExperienta;
		this.tarifPerOra=tarifPerOra;
	}

	public Angajat() {
		this.nume="necunoscut";
		this.varsta=-1;
		this.aniExperienta=-1;
		this.tarifPerOra=-1;
	}
	
	public String toString() {
		return nume + ", " + varsta + " de ani, " + aniExperienta + " ani experienta, " + tarifPerOra + " pe ora";
	}

	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public int getVarsta() {
		return varsta;
	}

	public void setVarsta(int varsta) {
		this.varsta = varsta;
	}

	public int getAniExperienta() {
		return aniExperienta;
	}

	public void setAniExperienta(int aniExperienta) {
		this.aniExperienta = aniExperienta;
	}

	public int getTarifPerOra() {
		return tarifPerOra;
	}

	public void setTarifPerOra(int tarifPerOra) {
		this.tarifPerOra = tarifPerOra;
	}
	
	
}
