
public class Companie {
	public Angajat[] angajati=new Angajat[10];
	public int nrAngajati;
	
	public Companie() {
		
	}
	
	public void adaugaAngajat(Angajat x) {
		this.angajati[nrAngajati]=x;
		this.nrAngajati++;
		System.out.println("Angajat adaugat");
	}
	
	public void stergeAngajat(Angajat x) {
		for (int i=0;i<nrAngajati;i++) {
			if (x==angajati[i]) {
				angajati[i]=null;
				System.out.println("Angajat sters");
			}
		}
	}
	
	public void afisare() {
		for (int i=0;i<nrAngajati;i++) {
			if (angajati[i]!=null)
			System.out.println(angajati[i].toString());
		}
	}

	public Angajat[] getAngajati() {
		return angajati;
	}

	public void setAngajati(Angajat[] angajati) {
		this.angajati = angajati;
	}

	public int getNrAngajati() {
		return nrAngajati;
	}

	public void setNrAngajati(int nrAngajati) {
		this.nrAngajati = nrAngajati;
	}
	
	

}
