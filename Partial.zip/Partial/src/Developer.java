
public class Developer extends Angajat {
	String task;
	
	public void rezolvaTask(String task) {
		this.task=task;
		System.out.println(nume + " " + task);
	}

	public Developer(String nume, int varsta, int aniExperienta, int tarifPerOra) {
		super(nume, varsta, aniExperienta, tarifPerOra);
		
	}
}
